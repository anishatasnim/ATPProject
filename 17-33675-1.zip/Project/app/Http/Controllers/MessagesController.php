<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Messages;
use App\Customer;


class MessagesController extends Controller
{
    
    public function index(Request $req){
    	return view('message.index');

    }
    


    public function send(Request $req){
        $messages                  = new Messages();
        $messages->to_email        = $req->to_email;
        $messages->from_email      = $req->from_email;
        $messages->message         = $req->message;
    
        if($messages->save()){
           return view('message.view');
        }else{
            return redirect()->route('login.reg');
            $req->session()->flash('msg', 'invalid');
        }}

        public function list(Request $req){
        //$students = $this->getStudentList();
        $messages = Messages::all();
        return view('message.view', ['messages'=>$messages]);
    }
    
}
