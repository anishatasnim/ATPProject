<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Customer;
use App\Job;


class JobController extends Controller
{
    
    public function index(Request $req){
    	return view('post.index');
    }
    

    public function insert(Request $req){
        
        $job                  = new Job();
        $job->user_id         = $req->user_id;
        $job->user_email      = $req->user_email;
        $job->status          = $req->status;
        $job->category        = $req->category;
        $job->title           = $req->title;
        $job->description     = $req->description;
        $job->fee             = $req->fee;

    
        if($job->save()){
            return redirect()->route('home.index');
        }else{
            return redirect()->route('login.reg');
            $req->session()->flash('msg', 'invalid');
        }
    }
}
