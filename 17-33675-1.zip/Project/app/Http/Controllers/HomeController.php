<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\User;
use App\Customer;
use App\Job;
use App\Messages;
class HomeController extends BaseController
{
   public function index(){
    	return view('home.index');
    }
	public function show(){
        $allCustomer = Customer::all();
        return view('home.showProfile',['allCustomer'=>$allCustomer]);
    }
	
    public function edit($id)
    {
        $customer = Customer::where('id', $id)->first();

        return view('home.edit', compact('customer'));
    }

    public function update(Request $req, $id)
    {
    	 $validatedData = $req->validate([
            'user_name' => 'required|max:30|min:5',
            'user_email' => 'email',
            'user_password' => 'required|min:5',
            'user_phoneno' => 'required',
            'user_address' => 'required',
        ]);
        $customer = array();
        $customer->user_name =$req->user_name;        
        $customer->user_email =$req->user_email;        
        $customer->user_password=$req->user_password;
        $customer->user_address =$req->user_address;
        $customer->user_phoneno=$req->user_phoneno;
        
       
        $customer->save();
        //return view('admin.index');
		$allCustomer = Customer::all();
        return view('home.showProfile',['allCustomer'=>$allCustomer]);

    }
    public function delete($id)
    {
        $customers=DB::table('customers')->where('id',$id)->delete();
       return redirect()->route('home.index');
        
    }
    
}
