<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Customer;
use App\Job;
use App\Forum;


class ForumController extends Controller
{
    
    public function index(Request $req){
    	return view('forum.index');
    }
    

    public function insert(Request $req){
        
        $forum                  = new Forum();
        $forum->user_email      = $req->user_email;
        $forum->title           = $req->title;
        $forum->description     = $req->description;
    
    
        if($forum->save()){
            return redirect()->route('home.index');
        }else{
            return redirect()->route('login.reg');
            $req->session()->flash('msg', 'invalid');
        }
    }
}
