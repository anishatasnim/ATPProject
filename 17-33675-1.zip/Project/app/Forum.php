<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class forum extends Model
{
	public $timestamps = false;
}

