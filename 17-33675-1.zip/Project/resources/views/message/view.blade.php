<!DOCTYPE html>
<html>
<head>
	<title>Message</title>
</head>
<body>	

	<h1>All Messages</h1>&nbsp
	<a href="{{route('home.index')}}">back</a> |
	<a href="/logout">Logout</a> 

	<table border="1">
		<tr>
			<th>ID</th>
			<th>To</th>
			<th>From</th>
			<th>Message</th>
			
			<!-- <th>Action</th> -->
		</tr>
		
		 @for($i = 0; $i < count($messages); $i++)
        <tr>

        	
            <td>{{ $messages[$i]->id }}</td>
            <td>{{ $messages[$i]->to_email }}</td>
            <td>{{ $messages[$i]->from_email }}</td>
            <td>{{ $messages[$i]->message}}</td>
           
        </tr>
    @endfor
	</table>

</body>
</html>