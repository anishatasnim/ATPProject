<!DOCTYPE html>
<html>
<head>
	<title>Message</title>
</head>
<body>	

	<h1>Message</h1>&nbsp
	<a href="{{route('home.index')}}">Back</a> <br>|
	<a href="{{route('logout')}}">Logout</a> <br>

	<form method="post" enctype="multipart/form-data">
		{{csrf_field()}}
		<table>
			<tr>
				<td>To</td>
				<td><input type="text" name="to_email"></td>
			</tr>

			<tr>
				<td>From</td>
				<td><input type="text" name="from_email"></td>
			</tr>
			<tr>
				<td>Message</td>
				<td><input type="text" name="message"></td>
			</tr>
			<input type="submit" name="submit" value="Submit" >
		</table>
	</form>
	
	@foreach($errors->all() as $err)
		{{$err}} <br>
	@endforeach

</body>
</html>