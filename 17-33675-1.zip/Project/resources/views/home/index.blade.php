<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Home! {{session('user_name')}}</h1>&nbsp

	<a href="/create">Create User</a> |
	<a href="{{route('sendMessage')}}">Send Message </a>|
	<a href="{{route('view')}}">See Messages</a>|
	<a href="{{route('postJob')}}">Post a job </a>|
	<a href="{{route('postForum')}}">Post in a Forum</a>|
	<a href="{{route('showProfile')}}">View Profile</a>
	<a href="{{route('logout')}}">Logout</a> 
	 
</body>
</html>

