<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="{{route('edit',['id' => $customer->id])}}" method="post">
        {{csrf_field()}}
        <h3>editprofile </h3>
        <label for="id">Id</label><br>
		<input type="text" name="id" readonly value="{{$customer['id']}}"><br>
        <label for="">email</label><br>
        <input type="text" name="user_email" value="{{$customer['user_email']}}" required><br>
        <label for="">password</label><br>
        <input type="text" name="user_password" value="{{$customer['user_password']}}" required><br>
        <label for="">name</label><br>
        <input type="text" name="user_name" value="{{$customer['user_name']}}" required><br>
        <label for="">phoneno</label><br>
        <input type="text" name="user_phoneno" value="{{$customer['user_phoneno']}}" required><br>
        <label for="">address</label><br>
        <input type="text" name="user_address" value="{{$customer['user_address']}}" required><br>
        <button type="submit">Submit</button>|
        <a href="{{route('home.index')}}">back</a> 
        
    </form>
</body>
</html>
