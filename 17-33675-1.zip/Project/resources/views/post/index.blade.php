<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Registration</h1>&nbsp
	<a href="{{route('home.index')}}">Back</a> <br>|
	<a href="{{route('logout')}}">Logout</a> <br>

	<form method="post" enctype="multipart/form-data">
		{{csrf_field()}}
		<table>
			<tr>
				<td>User Id</td>
				<td><input type="text" name="user_id"></td>
			</tr>

			<tr>
				<td>User Email</td>
				<td><input type="text" name="user_email"></td>
			</tr>

			<tr>
				<td>Status</td>
				<td><input type="text" name="status"></td>
			</tr>
			<tr>
				<td>Category</td>
				<td><input type="text" name="category"></td>
			</tr>
			<tr>
				<td>Title</td>
				<td><input type="text" name="title" ></td>
			</tr>
			<tr>
				<td>Description</td>
				<td><input type="text" name="description" ></td>
			</tr>
			<tr>
				<td>Fee</td>
				<td><input type="text" name="fee" ></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Create"></td>
			</tr>
		</table>
	</form>
	
	@foreach($errors->all() as $err)
		{{$err}} <br>
	@endforeach

</body>
</html>