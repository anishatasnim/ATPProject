<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h1>Login Page</h1>
	<form method="post" >
		@csrf
<!-- 		{{csrf_field()}} -->		
<!-- 		<input type="hidden" name="_token" value="{{csrf_token()}}"> -->
		Username: <input type="text" name="user_name" > <br>
		Password: <input type="password" name="user_password" ><br>
		<input type="submit" name="submit" value="Submit" >
		<a href="{{route('registration')}}">Don't Have Acount? Sign up</a>
	</form>

	<h3>{{session('msg')}}</h3>
</body>
</html>