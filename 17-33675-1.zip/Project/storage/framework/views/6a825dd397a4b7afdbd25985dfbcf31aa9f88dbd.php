<!DOCTYPE html>
<html>
<head>
	<title>Message</title>
</head>
<body>	

	<h1>All Messages</h1>&nbsp
	<a href="<?php echo e(route('home.index')); ?>">back</a> |
	<a href="/logout">Logout</a> 

	<table border="1">
		<tr>
			<th>ID</th>
			<th>To</th>
			<th>From</th>
			<th>Message</th>
			
			<!-- <th>Action</th> -->
		</tr>
		
		 <?php for($i = 0; $i < count($messages); $i++): ?>
        <tr>

        	
            <td><?php echo e($messages[$i]->id); ?></td>
            <td><?php echo e($messages[$i]->to_email); ?></td>
            <td><?php echo e($messages[$i]->from_email); ?></td>
            <td><?php echo e($messages[$i]->message); ?></td>
           
        </tr>
    <?php endfor; ?>
	</table>

</body>
</html><?php /**PATH C:\xampp\htdocs\Project\resources\views/message/view.blade.php ENDPATH**/ ?>