<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="<?php echo e(route('edit',['id' => $customer->id])); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h3>editprofile </h3>
        <label for="id">Id</label><br>
		<input type="text" name="id" readonly value="<?php echo e($customer['id']); ?>"><br>
        <label for="">email</label><br>
        <input type="text" name="user_email" value="<?php echo e($customer['user_email']); ?>" required><br>
        <label for="">password</label><br>
        <input type="text" name="user_password" value="<?php echo e($customer['user_password']); ?>" required><br>
        <label for="">name</label><br>
        <input type="text" name="user_name" value="<?php echo e($customer['user_name']); ?>" required><br>
        <label for="">phoneno</label><br>
        <input type="text" name="user_phoneno" value="<?php echo e($customer['user_phoneno']); ?>" required><br>
        <label for="">address</label><br>
        <input type="text" name="user_address" value="<?php echo e($customer['user_address']); ?>" required><br>
        <button type="submit">Submit</button>|
        <a href="<?php echo e(route('home.index')); ?>">back</a> 
        
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Project\resources\views/home/edit.blade.php ENDPATH**/ ?>