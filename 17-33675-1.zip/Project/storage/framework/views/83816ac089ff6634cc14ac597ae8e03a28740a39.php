<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h1>Login Page</h1>
	<form method="post" >
		<?php echo csrf_field(); ?>
<!-- 		<?php echo e(csrf_field()); ?> -->		
<!-- 		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> -->
		Username: <input type="text" name="user_name" > <br>
		Password: <input type="password" name="user_password" ><br>
		<input type="submit" name="submit" value="Submit" >
		<a href="<?php echo e(route('registration')); ?>">Don't Have Acount? Sign up</a>
	</form>

	<h3><?php echo e(session('msg')); ?></h3>
</body>
</html><?php /**PATH D:\Spring 2020\Final\ATP 3\Project\resources\views/login/index.blade.php ENDPATH**/ ?>