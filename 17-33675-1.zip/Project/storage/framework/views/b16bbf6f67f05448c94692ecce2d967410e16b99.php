<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Home! <?php echo e(session('user_name')); ?></h1>&nbsp

	<a href="/create">Create User</a> |
	<a href="<?php echo e(route('sendMessage')); ?>">Send Message </a>|
	<a href="<?php echo e(route('view')); ?>">See Messages</a>|
	<a href="<?php echo e(route('postJob')); ?>">Post a job </a>|
	<a href="<?php echo e(route('postForum')); ?>">Post in a Forum</a>|
	<a href="<?php echo e(route('showProfile')); ?>">View Profile</a>
	<a href="<?php echo e(route('logout')); ?>">Logout</a> 
	 
</body>
</html>

<?php /**PATH C:\xampp\htdocs\Project\resources\views/home/index.blade.php ENDPATH**/ ?>