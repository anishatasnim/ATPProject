<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Registration</h1>&nbsp
	<a href="<?php echo e(route('home.index')); ?>">Back</a> <br>|
	<a href="<?php echo e(route('logout')); ?>">Logout</a> <br>

	<form method="post" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<table>
			<tr>
				<td>User Id</td>
				<td><input type="text" name="user_id"></td>
			</tr>

			<tr>
				<td>User Email</td>
				<td><input type="text" name="user_email"></td>
			</tr>

			<tr>
				<td>Status</td>
				<td><input type="text" name="status"></td>
			</tr>
			<tr>
				<td>Category</td>
				<td><input type="text" name="category"></td>
			</tr>
			<tr>
				<td>Title</td>
				<td><input type="text" name="title" ></td>
			</tr>
			<tr>
				<td>Description</td>
				<td><input type="text" name="description" ></td>
			</tr>
			<tr>
				<td>Fee</td>
				<td><input type="text" name="fee" ></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Create"></td>
			</tr>
		</table>
	</form>
	
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?> <br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\Project\resources\views/post/index.blade.php ENDPATH**/ ?>