<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Registration</h1>&nbsp
	<a href="<?php echo e(route('login')); ?>">back</a> |
	<a href="/logout">Logout</a> <br>

	<form method="post" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<table>
			<tr>
				<td>Username</td>
				<td><input type="text" name="user_name"></td>
			</tr>

			<tr>
				<td>Email</td>
				<td><input type="text" name="user_email"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="user_password"></td>
			</tr>
			<tr>
				<td>Phone no</td>
				<td><input type="text" name="user_phoneno" ></td>
			</tr>
			<tr>
				<td>Address</td>
				<td><input type="text" name="user_address" ></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Create"></td>
			</tr>
		</table>
	</form>
	
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?> <br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\Project\resources\views/login/reg.blade.php ENDPATH**/ ?>