<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<body>
    <br><h1><b>ownprofile</b></h1>
   
	<br><br><br>
	
	<table border="1">
		<tr>
		     <th>Id</th>
			<th>Name</th>
			<th>Email</th>
            <th>password</th>
            <th>address</th>
            <th>phoneno</th>
			
			<th>Action</th>
		</tr>

		<?php $__currentLoopData = $allCustomer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		     <td><?php echo e($customer['id']); ?></td>
			<td><?php echo e($customer['user_name']); ?></td>
			<td><?php echo e($customer['user_email']); ?></td>
			<td><?php echo e($customer['user_password']); ?></td>
			<td><?php echo e($customer['user_address']); ?></td>
			<td><?php echo e($customer['user_phoneno']); ?></td>
			
			<td>
                <a href="<?php echo e(route('edit', $customer['id'])); ?>">Edit</a>
			</td>
			<td>
                <a href="<?php echo e(route('delete', $customer['id'])); ?>">Delete</a>
			</td>
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<a href="<?php echo e(route('home.index')); ?>">Back</a>

</body>
</html>

<?php /**PATH C:\xampp\htdocs\Project\resources\views/home/showProfile.blade.php ENDPATH**/ ?>