<!DOCTYPE html>
<html>
<head>
	<title>Message</title>
</head>
<body>	

	<h1>Message</h1>&nbsp
	<a href="<?php echo e(route('home.index')); ?>">Back</a> <br>|
	<a href="<?php echo e(route('logout')); ?>">Logout</a> <br>

	<form method="post" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<table>
			<tr>
				<td>To</td>
				<td><input type="text" name="to_email"></td>
			</tr>

			<tr>
				<td>From</td>
				<td><input type="text" name="from_email"></td>
			</tr>
			<tr>
				<td>Message</td>
				<td><input type="text" name="message"></td>
			</tr>
			<input type="submit" name="submit" value="Submit" >
		</table>
	</form>
	
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?> <br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\Project\resources\views/message/index.blade.php ENDPATH**/ ?>