<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/mywebsite', 'WebsiteController@index');

Route::get('/', function () {
    return view('welcome');
});
Route::get('/login', 'LoginController@index')->name('login');
Route::post('/login', 'LoginController@verify');
Route::get('/logout', 'LogoutController@index')->name('logout');

Route::get('/login/registration','LoginController@reg')->name('registration');
Route::post('/login/registration','LoginController@insert')->name('registration');

Route::get('/system/ownprofile', 'WorkerController@show')->name('ownprofile');
Route::get('/home', 'HomeController@index')->name('home.index');
Route::get('/home/showProfile','HomeController@show')->name('showProfile');

Route::get('/home/showProfile/{id}/edit','HomeController@edit')->name('edit');
Route::post('/home/showProfile/{id}/edit','HomeController@update')->name('edit');
Route::get('/home/showProfile/{id}/delete','HomeController@delete')->name('delete');


Route::get('/home/message','MessagesController@index');
Route::post('/home/message','MessagesController@send')->name('sendMessage');
Route::get('/home/message/view','MessagesController@list')->name('view');

Route::get('/home/postJob','JobController@index')->name('postJob');
Route::post('/home/postJob','JobController@insert')->name('postJob');

Route::get('/home/postForum','ForumController@index')->name('postForum');
Route::post('/home/postForum','ForumController@insert')->name('postForum');

// Route::get('/home/{id}/edit', 'HomeController@show')->name('edit');
// Route::post('/home/{id}/edit', 'HomeController@edit')->name('edit');
